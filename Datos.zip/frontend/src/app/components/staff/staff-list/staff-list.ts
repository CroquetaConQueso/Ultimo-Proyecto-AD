import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { RouterLink, Router } from '@angular/router';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import { Staff } from '../../../models';

@Component({
  selector: 'app-staff-list',
  standalone: true,
  imports: [RouterLink, NgFor, NgIf, FormsModule],
  templateUrl: './staff-list.html',
  styleUrl: './staff-list.css'
})
export class StaffList implements OnInit {
  staffList: Staff[] = [];
  filteredList: Staff[] = [];
  searchTerm: string = '';
  selectedIds: Set<string> = new Set();

  constructor(private api: ApiService, private cdr: ChangeDetectorRef, private router: Router) { }

  ngOnInit(): void {
    this.loadStaff();
  }

  loadStaff() {
    this.api.getStaff().subscribe({
      next: (data) => {
        this.staffList = data;
        this.filterList();
        this.cdr.detectChanges();
      },
      error: (err) => console.error('Error loading staff', err)
    });
  }

  filterList() {
    if (!this.searchTerm) {
      this.filteredList = [...this.staffList];
    } else {
      const term = this.searchTerm.toLowerCase();
      this.filteredList = this.staffList.filter(s =>
        s.name.toLowerCase().includes(term) ||
        s.role.toLowerCase().includes(term) ||
        (s.specialization && s.specialization.toLowerCase().includes(term))
      );
    }
    // Update selection to remove hidden items ?? No, standard behavior is keeping them.
  }

  // Selection Logic
  toggleSelection(id: string | undefined) {
    if (!id) return;
    if (this.selectedIds.has(id)) {
      this.selectedIds.delete(id);
    } else {
      this.selectedIds.add(id);
    }
  }

  toggleAll(event: any) {
    if (event.target.checked) {
      this.filteredList.forEach(s => {
        if (s.id) this.selectedIds.add(s.id);
      });
    } else {
      this.selectedIds.clear(); // Or just remove visible? "Deselect all" typically means clear.
    }
  }

  isSelected(id: string | undefined): boolean {
    return id ? this.selectedIds.has(id) : false;
  }

  get isOneSelected(): boolean {
    return this.selectedIds.size === 1;
  }

  get hasSelection(): boolean {
    return this.selectedIds.size > 0;
  }

  // Actions
  refresh() {
    this.loadStaff();
    this.selectedIds.clear();
  }

  resetSearch() {
    this.searchTerm = '';
    this.filterList();
  }

  deleteSelected() {
    if (!this.hasSelection) return;

    if (confirm(`¿Eliminar ${this.selectedIds.size} registros seleccionados?`)) {
      const ids = Array.from(this.selectedIds);
      // Simulate batch delete by iterating (Backend requirement said "Borrar por lote" but we only have deleteById for now)
      // We will implement iteration for now.
      let completed = 0;
      ids.forEach(id => {
        this.api.deleteStaff(id).subscribe(() => {
          completed++;
          if (completed === ids.length) {
            this.selectedIds.clear();
            this.loadStaff();
          }
        });
      });
    }
  }

  editSelected() {
    if (!this.isOneSelected) return;
    const id = this.selectedIds.values().next().value;
    this.router.navigate(['/staff/edit', id]);
  }

  inspectSelected() {
    if (!this.isOneSelected) return;
    const id = this.selectedIds.values().next().value;
    // Assuming we reuse the form for inspection, maybe disabled
    this.router.navigate(['/staff/edit', id]); // Or /inspect/ if we had it. Let's use edit for now or pass a query param.
    // User asked for "Pantalla de Inspección". Let's route to edit but we'll handle "readonly" state there.
  }

  viewSelected() {
    if (!this.hasSelection) return;
    const names = this.staffList
      .filter(s => s.id && this.selectedIds.has(s.id))
      .map(s => s.name)
      .join(', ');
    alert('Seleccionados: ' + names);
  }

  getRoleName(role: string): string {
    const map: Record<string, string> = {
      'DOCTOR': 'Doctor',
      'NURSE': 'Enfermero/a',
      'ADMIN': 'Administrador'
    };
    return map[role] || role;
  }
}