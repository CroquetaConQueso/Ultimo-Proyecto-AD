import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ApiService } from '../../../services/api.service';
import { Treatment } from '../../../models';

@Component({
  selector: 'app-treatment-form',
  standalone: true,
  imports: [FormsModule, DatePipe],
  templateUrl: './treatment-form.html',
  styleUrl: './treatment-form.css'
})
export class TreatmentForm {
  treatment: Treatment = {
    patientId: '',
    description: '',
    startDate: new Date(),
    endDate: new Date()
  };

  constructor(private api: ApiService, private router: Router) { }

  save() {
    this.api.createTreatment(this.treatment).subscribe(() => {
      this.router.navigate(['/treatments']);
    });
  }

  cancel() {
    this.router.navigate(['/treatments']);
  }
}