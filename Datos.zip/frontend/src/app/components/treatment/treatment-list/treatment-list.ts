import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NgFor, NgIf, DatePipe } from '@angular/common';
import { ApiService } from '../../../services/api.service';
import { Treatment } from '../../../models';

@Component({
  selector: 'app-treatment-list',
  standalone: true,
  imports: [RouterLink, NgFor, NgIf, DatePipe],
  templateUrl: './treatment-list.html',
  styleUrl: './treatment-list.css'
})
export class TreatmentList implements OnInit {
  treatments: Treatment[] = [];

  constructor(private api: ApiService) { }

  ngOnInit() {
    this.api.getTreatments().subscribe(data => this.treatments = data);
  }

  delete(id: string | undefined) {
    if (id && confirm('¿Eliminar este tratamiento?')) {
      this.api.deleteTreatment(id).subscribe(() => this.ngOnInit());
    }
  }
}