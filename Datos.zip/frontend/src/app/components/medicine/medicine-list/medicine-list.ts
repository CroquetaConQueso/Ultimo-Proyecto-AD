import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { NgFor, NgIf } from '@angular/common';
import { ApiService } from '../../../services/api.service';
import { Medicine } from '../../../models';

@Component({
  selector: 'app-medicine-list',
  standalone: true,
  imports: [RouterLink, NgFor, NgIf],
  templateUrl: './medicine-list.html',
  styleUrl: './medicine-list.css'
})
export class MedicineList implements OnInit {
  medicines: Medicine[] = [];

  constructor(private api: ApiService) { }

  ngOnInit() {
    this.api.getMedicines().subscribe(data => this.medicines = data);
  }

  delete(id: string | undefined) {
    if (id && confirm('¿Eliminar medicamento del inventario?')) {
      this.api.deleteMedicine(id).subscribe(() => this.ngOnInit());
    }
  }
}